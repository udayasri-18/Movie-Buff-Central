// routes/quiz.js
const express = require('express');
const router = express.Router();

const quizQuestions = [
  {
    question: "What is the name of Harry Potter's owl?",
    options: ["Hedwig", "Crookshanks", "Fawkes"],
    answer: "Hedwig"
  },
  {
    question: "Who teaches potions at Hogwarts?",
    options: ["Snape", "McGonagall", "Dumbledore"],
    answer: "Snape"
  }
  // Add more questions here
];

router.get('/', (req, res) => {
  res.render('quiz', { quizQuestions });
});

module.exports = router;
