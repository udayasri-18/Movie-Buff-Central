// routes/characters.js
const express = require('express');
const router = express.Router();

const characters = [
  {
    name: "Harry Potter",
    image: "/images/harry_potter.jpg",
    description: "The Boy Who Lived, Harry is the central character in the Harry Potter series.",
    facts: ["He has a lightning bolt-shaped scar.", "He can speak Parseltongue."]
  },
  {
    name: "Hermione Granger",
    image: "/images/hermione_granger.jpg",
    description: "Hermione is known for her intelligence and bravery.",
    facts: ["She is a Muggle-born witch.", "She was nearly placed in Ravenclaw."]
  }
  // Add more characters here
];

router.get('/', (req, res) => {
  res.render('characters', { characters });
});

module.exports = router;
