const quotes = [
    "It is our choices, Harry, that show what we truly are, far more than our abilities.",
    "I solemnly swear I am up to no good.",
    "Yer a wizard, Harry!"
  ];
  
  function displayQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    document.getElementById('quote').innerText = quotes[randomIndex];
  }
  
  window.onload = displayQuote;
  