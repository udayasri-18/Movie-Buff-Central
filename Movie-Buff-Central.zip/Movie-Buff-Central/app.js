const express = require('express');
const path = require('path');
const app = express();

// Set view engine to EJS
app.set('view engine', 'ejs');

// Set the views directory
app.set('views', path.join(__dirname, 'views'));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Home Route
app.get('/', (req, res) => {
    res.render('index', { title: 'Home' });
});

// Trivia Quiz Route
app.get('/quiz', (req, res) => {
    res.render('quiz', { title: 'Trivia Quiz' });
});

// Character Bios Route
app.get('/characters', (req, res) => {
    res.render('characters', { title: 'Character Bios' });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
